var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__0r1-5qr._.js")
R.c("server/chunks/[root-of-the-server]__16sm_y2._.js")
R.m(62395)
module.exports=R.m(62395).exports
