globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/HEmF2pv3_A5wHK4G5Wjuz/_buildManifest.js",
    "static/HEmF2pv3_A5wHK4G5Wjuz/_ssgManifest.js",
    "static/HEmF2pv3_A5wHK4G5Wjuz/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/19mx3mg6lkumu.js",
    "static/chunks/0c0vjb_v3lq5t.js",
    "static/chunks/2-rtuqsgzmno4.js",
    "static/chunks/turbopack-226hxxbc_i1xw.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
