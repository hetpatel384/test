module.exports=[9612,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bulk-analysis_route_actions_0u_phy_.js.map