module.exports=[2694,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_github_start_route_actions_0jn1xgw.js.map