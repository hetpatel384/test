module.exports=[54814,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_settings_jira_route_actions_1_fjl3i.js.map