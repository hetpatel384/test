module.exports=[46900,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ticket_%5BticketKey%5D_route_actions_1us6hjj.js.map