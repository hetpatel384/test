module.exports=[25778,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_project_%5BprojectKey%5D_route_actions_02much5.js.map