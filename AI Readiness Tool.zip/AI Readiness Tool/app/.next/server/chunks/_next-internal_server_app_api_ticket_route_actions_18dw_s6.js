module.exports=[16157,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ticket_route_actions_18dw_s6.js.map