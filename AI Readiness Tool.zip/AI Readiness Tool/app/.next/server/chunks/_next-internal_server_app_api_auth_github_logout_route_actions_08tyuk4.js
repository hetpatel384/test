module.exports=[84666,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_github_logout_route_actions_08tyuk4.js.map