module.exports=[14276,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_refinement_from-score_route_actions_1ikewrq.js.map