module.exports=[5262,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_github_cancel_route_actions_0bct4di.js.map