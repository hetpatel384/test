:HL["/_next/static/chunks/41z83mrqsgvy6.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"HEmF2pv3_A5wHK4G5Wjuz"}
