var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/refinement/from-score/route.js")
R.c("server/chunks/[root-of-the-server]__03dgt-v._.js")
R.c("server/chunks/_0urmb8e._.js")
R.c("server/chunks/[root-of-the-server]__19jz899._.js")
R.c("server/chunks/_1m1bs0q._.js")
R.c("server/chunks/[root-of-the-server]__01xi-zc._.js")
R.c("server/chunks/_next-internal_server_app_api_refinement_from-score_route_actions_1ikewrq.js")
R.m(7641)
module.exports=R.m(7641).exports
