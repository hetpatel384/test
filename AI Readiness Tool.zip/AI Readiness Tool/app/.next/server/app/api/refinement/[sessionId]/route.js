var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/refinement/[sessionId]/route.js")
R.c("server/chunks/[root-of-the-server]__03c-0yv._.js")
R.c("server/chunks/_0urmb8e._.js")
R.c("server/chunks/[root-of-the-server]__19jz899._.js")
R.c("server/chunks/_1m1bs0q._.js")
R.c("server/chunks/[root-of-the-server]__0pl05v6._.js")
R.c("server/chunks/_next-internal_server_app_api_refinement_[sessionId]_route_actions_1hrx-u1.js")
R.m(50999)
module.exports=R.m(50999).exports
