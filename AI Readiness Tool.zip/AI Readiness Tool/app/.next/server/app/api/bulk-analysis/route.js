var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/bulk-analysis/route.js")
R.c("server/chunks/_0urmb8e._.js")
R.c("server/chunks/[root-of-the-server]__1vm86j5._.js")
R.c("server/chunks/_15_q1vn._.js")
R.c("server/chunks/[root-of-the-server]__19jz899._.js")
R.c("server/chunks/[root-of-the-server]__0vpzpjx._.js")
R.c("server/chunks/_next-internal_server_app_api_bulk-analysis_route_actions_0u_phy_.js")
R.m(45082)
module.exports=R.m(45082).exports
