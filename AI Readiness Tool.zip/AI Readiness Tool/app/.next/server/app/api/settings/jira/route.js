var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/jira/route.js")
R.c("server/chunks/[root-of-the-server]__11p28_t._.js")
R.c("server/chunks/_0dffmm_._.js")
R.c("server/chunks/_15_q1vn._.js")
R.c("server/chunks/[root-of-the-server]__19jz899._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_jira_route_actions_1_fjl3i.js")
R.m(83789)
module.exports=R.m(83789).exports
