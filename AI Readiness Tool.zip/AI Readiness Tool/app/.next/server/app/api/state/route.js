var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/state/route.js")
R.c("server/chunks/[root-of-the-server]__1cbwasp._.js")
R.c("server/chunks/[root-of-the-server]__0yknfe5._.js")
R.c("server/chunks/_1m1bs0q._.js")
R.c("server/chunks/_next-internal_server_app_api_state_route_actions_16zr0br.js")
R.m(43119)
module.exports=R.m(43119).exports
