var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ticket/[ticketKey]/route.js")
R.c("server/chunks/[root-of-the-server]__06nnry-._.js")
R.c("server/chunks/_0dffmm_._.js")
R.c("server/chunks/_15_q1vn._.js")
R.c("server/chunks/[root-of-the-server]__19jz899._.js")
R.c("server/chunks/_next-internal_server_app_api_ticket_[ticketKey]_route_actions_1us6hjj.js")
R.m(17460)
module.exports=R.m(17460).exports
