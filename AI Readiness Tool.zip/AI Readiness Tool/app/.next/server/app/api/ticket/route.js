var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/ticket/route.js")
R.c("server/chunks/[root-of-the-server]__0v7-26u._.js")
R.c("server/chunks/_0dffmm_._.js")
R.c("server/chunks/_15_q1vn._.js")
R.c("server/chunks/[root-of-the-server]__19jz899._.js")
R.c("server/chunks/[root-of-the-server]__01xi-zc._.js")
R.c("server/chunks/_next-internal_server_app_api_ticket_route_actions_18dw_s6.js")
R.m(31432)
module.exports=R.m(31432).exports
