var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/project/[projectKey]/route.js")
R.c("server/chunks/[root-of-the-server]__10fbgsh._.js")
R.c("server/chunks/_0dffmm_._.js")
R.c("server/chunks/_15_q1vn._.js")
R.c("server/chunks/[root-of-the-server]__19jz899._.js")
R.c("server/chunks/_next-internal_server_app_api_project_[projectKey]_route_actions_02much5.js")
R.m(45311)
module.exports=R.m(45311).exports
