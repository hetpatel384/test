var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/github/poll/route.js")
R.c("server/chunks/[root-of-the-server]__0ra6y93._.js")
R.c("server/chunks/[root-of-the-server]__19jz899._.js")
R.c("server/chunks/_15_q1vn._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_github_poll_route_actions_1sm7605.js")
R.m(63901)
module.exports=R.m(63901).exports
