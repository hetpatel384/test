var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/github/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0rfy2v1._.js")
R.c("server/chunks/[root-of-the-server]__19jz899._.js")
R.c("server/chunks/_15_q1vn._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_github_logout_route_actions_08tyuk4.js")
R.m(95159)
module.exports=R.m(95159).exports
