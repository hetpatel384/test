var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/github/start/route.js")
R.c("server/chunks/[root-of-the-server]__0c4l94_._.js")
R.c("server/chunks/[root-of-the-server]__19jz899._.js")
R.c("server/chunks/_15_q1vn._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_github_start_route_actions_0jn1xgw.js")
R.m(7019)
module.exports=R.m(7019).exports
