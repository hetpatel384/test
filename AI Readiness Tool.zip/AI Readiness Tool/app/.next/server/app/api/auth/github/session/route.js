var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/github/session/route.js")
R.c("server/chunks/[root-of-the-server]__0_5eky-._.js")
R.c("server/chunks/[root-of-the-server]__19jz899._.js")
R.c("server/chunks/_15_q1vn._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_github_session_route_actions_1zbho6y.js")
R.m(4209)
module.exports=R.m(4209).exports
