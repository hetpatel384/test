var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/github/cancel/route.js")
R.c("server/chunks/[root-of-the-server]__10545lr._.js")
R.c("server/chunks/[root-of-the-server]__19jz899._.js")
R.c("server/chunks/_15_q1vn._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_github_cancel_route_actions_0bct4di.js")
R.m(57387)
module.exports=R.m(57387).exports
