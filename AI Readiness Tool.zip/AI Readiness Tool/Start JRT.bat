@echo off
title GitHub sign-in steps
if not exist "%~dp0runtime\node.exe" (
  echo The tool cannot start because its files are missing.
  echo.
  echo If you opened this file from inside the ZIP, close this window,
  echo right-click the ZIP, choose "Extract All", and then start
  echo "Start JRT.bat" from the extracted folder.
  echo.
  pause
  exit /b 1
)
"%~dp0runtime\node.exe" "%~dp0runtime\launch.mjs"
if errorlevel 1 (
  echo.
  echo The tool stopped because of a problem. See the message above.
  pause
)
