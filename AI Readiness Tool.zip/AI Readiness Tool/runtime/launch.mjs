// Starts Story Readiness on this PC: makes sure Copilot is installed and signed in, runs the app and opens it in the browser.
// Runs with the Node that ships inside the package, so nothing has to be installed first.
import { randomBytes } from "node:crypto";
import { spawn } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { runtimeOptions } from "./runtime-options.mjs";

const runtimeDir = path.dirname(fileURLToPath(import.meta.url));
const appDir = path.join(path.dirname(runtimeDir), "app");
const localAppData = process.env.LOCALAPPDATA ?? path.join(os.homedir(), "AppData", "Local");
// Saved Jira settings and results live outside the package folder, so replacing the folder with a newer version keeps them.
const dataDir = process.env.JRT_DATA_DIR ?? path.join(localAppData, "JRT");
const preferredPort = Number(process.env.JRT_PORT ?? 3517);

function readGithubOAuthClientId() {
  const configPath = path.join(runtimeDir, "config.json");
  const config = JSON.parse(readFileSync(configPath, "utf8"));
  if (typeof config.githubOAuthClientId !== "string" || !config.githubOAuthClientId.trim()) {
    throw new Error("The GitHub sign-in configuration is missing from this package.");
  }
  return config.githubOAuthClientId.trim();
}

function loadOrCreateGithubAuthKey() {
  const keyPath = path.join(dataDir, ".github-auth.key");
  if (existsSync(keyPath)) return readFileSync(keyPath, "utf8").trim();

  const key = randomBytes(32).toString("base64");
  try {
    writeFileSync(keyPath, key, { flag: "wx", mode: 0o600 });
    return key;
  } catch (error) {
    if (error?.code === "EEXIST") return readFileSync(keyPath, "utf8").trim();
    throw error;
  }
}

function say(message = "") {
  console.log(message);
}

async function respondsAsJrt(port) {
  try {
    const response = await fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(2000) });
    return response.ok && (await response.json()).status === "ok";
  } catch {
    return false;
  }
}

async function portIsFree(port) {
  const { createServer } = await import("node:net");
  return new Promise((resolve) => {
    const probe = createServer().once("error", () => resolve(false)).once("listening", () => probe.close(() => resolve(true)));
    probe.listen(port, "127.0.0.1");
  });
}

async function pickPort() {
  for (let port = preferredPort; port < preferredPort + 20; port++) {
    if (await portIsFree(port)) return port;
  }
  throw new Error(`No free port found from ${preferredPort} to ${preferredPort + 19}.`);
}

async function waitUntilReady(port, server) {
  for (let attempt = 0; attempt < 120; attempt++) {
    if (server.exitCode !== null) throw new Error("The app stopped while starting.");
    if (await respondsAsJrt(port)) return;
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  throw new Error("The app did not start within one minute.");
}

function openBrowser(url) {
  if (process.env.JRT_NO_BROWSER) return;
  spawn("cmd", ["/c", "start", "", url], { detached: true, stdio: "ignore" }).unref();
}

async function main() {
  say("Starting the tool...");

  // A second double-click just opens the copy that is already running.
  if (await respondsAsJrt(preferredPort)) {
    say("The tool is already running. Opening it in your browser.");
    openBrowser(`http://127.0.0.1:${preferredPort}/`);
    return;
  }

  mkdirSync(dataDir, { recursive: true });
  const githubOAuthClientId = readGithubOAuthClientId();
  const githubAuthEncryptionKey = loadOrCreateGithubAuthKey();
  const port = await pickPort();
  const appEnvironment = { ...process.env };
  for (const name of ["GITHUB_ALLOWED_ORG", "GITHUB_ALLOWED_USERS", "COPILOT_GITHUB_TOKEN", "GH_TOKEN", "GITHUB_TOKEN"]) {
    delete appEnvironment[name];
  }
  const server = spawn(process.execPath, [...runtimeOptions(), "server.js"], {
    cwd: appDir,
    stdio: ["ignore", "inherit", "inherit"],
    env: {
      ...appEnvironment,
      NODE_ENV: "production",
      JRT_DESKTOP_PACKAGE: "1",
      JRT_DATA_DIR: dataDir,
      GITHUB_OAUTH_CLIENT_ID: githubOAuthClientId,
      GITHUB_AUTH_ENCRYPTION_KEY: githubAuthEncryptionKey,
      PORT: String(port),
      // Only this PC can reach the app. Jira credentials are saved inside it, so it must not be reachable from the network.
      HOSTNAME: "127.0.0.1",
      SESSION_DATABASE_PATH: path.join(dataDir, "refinement.db"),
      JIRA_SETTINGS_KEY_PATH: path.join(dataDir, ".jira-settings.key"),
      RUBRIC_PROMPT_PATH: path.join(appDir, "src", "prompts", "dor-rubric.md"),
    },
  });
  await waitUntilReady(port, server);

  const url = `http://127.0.0.1:${port}/`;
  // ?setup=1 asks the app to open the Jira connection form when Jira is not connected yet.
  openBrowser(`${url}?setup=1`);
  say();
  say("The tool is open at:");
  say(url);
  say();
  say("To finish GitHub sign-in:");
  say("1. In the tool tab, select Continue with GitHub.");
  say("2. The GitHub device page opens in another tab, and a one-time code appears in the tool tab.");
  say("3. Return to the tool tab and click the code to copy it.");
  say("4. On the GitHub device page, paste the code and approve access.");
  say("5. Return to the tool tab. Sign-in will finish automatically.");
  say("6. If Jira settings appear, enter your Jira site URL, email, and API token.");
  say();
  say("Keep this window open while you use it. Close it to stop the app.");

  const code = await new Promise((resolve) => server.once("exit", resolve));
  throw new Error(`The app stopped unexpectedly (exit code ${code}).`);
}

main().catch((error) => {
  console.error(`\n${error instanceof Error ? error.message : error}`);
  process.exit(1);
});
