export function runtimeOptions(supportedFlags = process.allowedNodeEnvironmentFlags) {
  return ["--use-system-ca", "--use-env-proxy"].filter((flag) => supportedFlags.has(flag));
}